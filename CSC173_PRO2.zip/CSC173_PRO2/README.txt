Justin Shen
CSC173
Project 2
jshen37@u.rochester.edu

Collaborators: Chris Chen (schen133@u.rochester.edu), Jeffrey li(jli167@u.rochester.edu)


Build/Running instruction:
	1. cd the location of the file
	2. gcc -std=c99 -Wall -Werror -o  rexp *.c
	3. rexp.exe
	
PART1 in rdp.c & rdp.h
PART2 in tdp.c & tdp.h
PART3 in eva.c & eva.h
	
Sample Input/Output:

Enter input, enter QUIT to quit
a|b.c*
Recursive descent parser
E
  C
    S
      A
        X
          a
      ST
        eps
    CT
      eps
  ET
    |
    E
      C
        S
          A
            X
              b
          ST
            eps
        CT
          .
          C
            S
              A
                X
                  c
              ST
                *
                ST
                  eps
            CT
              eps
      ET
        eps
Table driven parser
E
 C
   S
     A
       X
         a
     ST
       esp
   CT
     esp
 ET
   |
   E
     C
       S
         A
           X
             b
         ST
           esp
       CT
         .
         C
           S
             A
               X
                 c
             ST
               *
               ST
                 esp
           CT
             esp
     ET
       esp
Evaluate parse expression
(UNION (ATOMIC a)(CONCAT (ATOMIC b)(CLOSURE (ATOMIC c))))
Accepted, please enter another input
QUIT
Program ends.
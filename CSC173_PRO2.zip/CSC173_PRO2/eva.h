#ifndef CSC173_pro2_eva_h
#define CSC173_pro2_eva_h

#endif
#include "rdp.h"

extern tree exptree(tree parsechui);
extern void prtexp(tree input);
